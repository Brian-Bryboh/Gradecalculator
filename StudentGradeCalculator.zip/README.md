# Student Grade Calculator

A simple Java console application to calculate a student's average marks and assign a grade.

## How to Run

1. Compile:
   ```bash
   javac src/GradeCalculator.java
   ```

2. Run:
   ```bash
   java -cp src GradeCalculator
   ```

## Features

- Accepts any number of subjects.
- Calculates average marks.
- Assigns grade from A to F.

## Author

Your Name
